RR GLOBAL TECHNOLOGIES — WEBSITE + INSTALLABLE WEB APP

Included:
- Responsive one-page website
- Course list, services, projects, leadership, enquiry form
- Progressive Web App (PWA) manifest and service worker
- Logo SVG
- Mobile-friendly navigation

IMPORTANT BEFORE PUBLISHING:
1. Contact details configured from the information supplied:\n   Phone / WhatsApp: +91 9688823859\n   Business email: rramm361@gmail.com
2. The enquiry form currently opens the visitor's email app with a prefilled draft; it does not store submissions or automatically send to a business inbox.
3. Placement assistance is described honestly; no guaranteed placements are claimed.
4. Add your own course fees, schedules, address and verified company details as needed.

FREE PUBLISHING (GitHub Pages):
1. Sign in or create an account at https://github.com
2. Create a new public repository named rr-global-technologies.
3. Upload index.html, logo.svg, manifest.webmanifest, sw.js, and README.txt.
4. Open repository Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch; select main and /(root), then Save.
6. Wait for deployment. GitHub Pages will show a shareable URL such as https://YOUR-USERNAME.github.io/rr-global-technologies/ .
7. Open that URL on mobile. On supported browsers, use the browser menu → Install app / Add to Home screen.

NOTE: The sample URL above is a pattern, not a live published link. The website is not publicly hosted by this package alone.

PHONE / WHATSAPP:
The website now includes:
Phone: tel:+919688823859
WhatsApp: https://wa.me/919688823859
Email: mailto:rramm361@gmail.com
